# CRUD en laravel
1. Estructura completa
`php artisan make:model practica -a`

2. Crear la tabla en database/migrations/2024_**_**_******_create_practica...
3. Comando migrate
`php artisan migrate`
4. Factory
5. Seeder:
    PracticaSeeder
    DatabaseSeeder
6. Migrate, crear los datos
`php artisan migrate:refresh --seed`
7. Request
    True
    return 'requiered'
8. Controller
    index
    create
    store
    show
    edit
    update
    destroy
9. Views
10. Routes
