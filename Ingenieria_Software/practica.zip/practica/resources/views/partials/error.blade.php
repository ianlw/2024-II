@if (count($errors))
    <div>
        <h1>¡Error!</h1>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </div>

@endif
