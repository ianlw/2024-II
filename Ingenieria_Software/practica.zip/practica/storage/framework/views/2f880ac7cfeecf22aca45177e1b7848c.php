<?php if(count($errors)): ?>
    <div>
        <h1>¡Error!</h1>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php endif; ?>
<?php /**PATH /mnt/Datos/UNSAAC/2024-II/Ingenieria_Software/practica/resources/views/partials/error.blade.php ENDPATH**/ ?>