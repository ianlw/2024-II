<?php if(session('mensaje')): ?>
    <div>
        <h1>¡Éxito!</h1>
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /mnt/Datos/UNSAAC/2024-II/Ingenieria_Software/practica/resources/views/partials/info.blade.php ENDPATH**/ ?>