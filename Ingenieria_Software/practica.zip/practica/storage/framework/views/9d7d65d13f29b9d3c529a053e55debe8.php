<h1>
    Agregar una Práctica
    <a href="<?php echo e(route('practica.index')); ?>">Volver</a>
</h1>

<?php echo $__env->make('partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form method="POST" action="<?php echo e(route('practica.store')); ?>">
    <?php echo csrf_field(); ?>
    Nombres <input type="text" name="nombre" /><br / />
    Edad <br /><input type="number" name="edad" /><br />
    Estado <br /><input type="checkbox" name="estado" value="1" />Echo<br />
    Tipo <br /><input type="radio" name="tipo" value="Aceptado" />Aceptado<br />
    <input type="radio" name="tipo" value="Negado" />Negado<br />
    <button type="submit">Guardar</button>
</form>
<?php /**PATH /mnt/Datos/UNSAAC/2024-II/Ingenieria_Software/practica/resources/views/practica/create.blade.php ENDPATH**/ ?>