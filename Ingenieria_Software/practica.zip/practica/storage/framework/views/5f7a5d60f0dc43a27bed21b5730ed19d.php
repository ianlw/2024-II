<head>
    <meta charset="UTF-8">
    <title>Sistema de practicas</title>
</head>
<h1>
    Lista de practicas <br>
    <a href="<?php echo e(route('practica.create')); ?>">Nuevo practica</a>
</h1>
<?php echo $__env->make('partials.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table border="1">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Edad</th>
            <th>Estado</th>
            <th>Tipo</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $practicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($practica->nombre); ?></td>
                <td><?php echo e($practica->edad); ?></td>
                <td><?php echo e($practica->estado); ?></td>
                <td><?php echo e($practica->tipo); ?></td>
                <td>
                    <a title="Ver" href="<?php echo e(route('practica.show', $practica)); ?>">Ver</a>
                    <a title="Editar" href="<?php echo e(route('practica.edit', $practica)); ?>">Editar</a>
                    <form method="POST" action="<?php echo e(route('practica.destroy', $practica)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Eliminar</button>

                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($practicas->links()); ?>

<?php /**PATH /mnt/Datos/UNSAAC/2024-II/Ingenieria_Software/practica/resources/views/practica/index.blade.php ENDPATH**/ ?>