<h1>
    Editar una Práctica
    <a href="<?php echo e(route('practica.index')); ?>">Volver</a>
</h1>

<?php echo $__env->make('partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form method="POST" action="<?php echo e(route('practica.update', $practica)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <b>ID:</b> <input type="text" value="<?php echo e($practica->id); ?>" readonly /><br />
    Nombres <input type="text" name="nombre" value="<?php echo e($practica->nombre); ?>" /><br / />
    Edad <br /><input type="number" name="edad" value="<?php echo e($practica->edad); ?>" /><br />
    Estado <br /><input type="checkbox" name="estado" value="1"
        <?php echo e($practica->estado == 1 ? 'checked' : ''); ?> />Echo<br />
    Tipo <br /><input type="radio" name="tipo" value="Aceptado"
        <?php echo e($practica->tipo == 'Aceptado' ? 'checked' : ''); ?> />Aceptado<br />
    <input type="radio" name="tipo" value="Negado"
        <?php echo e($practica->tipo == 'Negado' ? 'checked' : ''); ?> />Negado<br />
    <button type="submit">Actualizar</button>
</form>
<?php /**PATH /mnt/Datos/UNSAAC/2024-II/Ingenieria_Software/practica/resources/views/practica/edit.blade.php ENDPATH**/ ?>